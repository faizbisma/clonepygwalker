## How to Develop PyGWalker Locally

```bash
npm run dev:server
```