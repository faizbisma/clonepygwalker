import os

JUPYTER_BYTE_LIMIT = 1 << 24
JUPYTER_WIDGETS_BYTE_LIMIT = 1 << 20

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
